/** 
 * RegionStatus class is used to store the number of minions 
 * and presence of building in the region for the particular Player.
 */

package Game;

public class RegionStatus {
		int placedMinion;
		int placedbuilding;
}
