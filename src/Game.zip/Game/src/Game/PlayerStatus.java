/** 
 * PlayerStatus class is used to store the color, number of minions 
 * and presence of building in the region for the particular Player.
 */

package Game;

public class PlayerStatus {
	String color;
	int pMinionRegionwise;
	int pbuildingRegionwise;
}
