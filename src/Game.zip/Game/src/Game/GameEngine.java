package Game;

//import SavedGame;

//import SavedGame;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException; 
import org.jdom2.input.SAXBuilder;
import org.w3c.dom.*; 

public class GameEngine extends JFrame implements Runnable {
	
	public static Region objDSisters;
	public static Region objUEstate;
	public static Region objDLanding;
	public static Region objSGods;
	public static Region objTScours;
	public static Region objTHippo;
	public static Region objTShades;
	public static Region objDimwell;
	public static Region objLongwall;
	public static Region objIGods;
	public static Region objSSleepers;
	public static Region objNHill;

	public static Player pRed;
	public static Player pYellow;
	public static Player pGreen;
	public static Player pBlue;

	static int numPlayers;
	static List<Player> players = new ArrayList<Player>();
	static List<Region> regions = new ArrayList<Region>();
	
	static List<String> randomCards = new ArrayList<>();
	
	
	public GameEngine() {
		initComponents();
	}

	private void Load_GameActionPerformed(ActionEvent e) {
		  //SavedGame Loaded =new SavedGame();
		// TODO add your code here
		SAXBuilder builder = new SAXBuilder();
		File f = new File("./src/Saved_Game.xml");
		 
		  if(f.exists()){
			  
		try 
		{
		
			
			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse (new File("./src/Saved_Game.xml"));
			doc.getDocumentElement ().normalize ();
			
			NodeList listOfRegions = doc.getElementsByTagName("Region");
			int totalRegions = listOfRegions.getLength();
			
			NodeList listOfPlayers = doc.getElementsByTagName("Player");
			//System.out.println("length: "+ totalPersons);
			for(int s=0; s<listOfRegions.getLength() ; s++)
			{
				Node firstRegionNode = listOfRegions.item(s);
				if(firstRegionNode.getNodeType() == Node.ELEMENT_NODE)
				{
					Element firstRegionElement = (Element)firstRegionNode; 
					
					// region number
					NodeList RegionNumberList = firstRegionElement.getElementsByTagName("RegionNumber");
					Element RegionNumberElement = (Element)RegionNumberList.item(0);
					NodeList RNList = RegionNumberElement.getChildNodes();
					regions.get(s).rNumber = Integer.parseInt(RNList.item(0).getNodeValue());
					//System.out.println(regions.get(s).rNumber);
					
					// name of region
					NodeList RegionNameList = (NodeList) firstRegionElement.getElementsByTagName("Name");
					Element RegionNameElement = (Element)RegionNameList.item(0);
					NodeList NameList = RegionNameElement.getChildNodes();
					regions.get(s).rName = NameList.item(0).getNodeValue();
					//System.out.println(regions.get(s).rName);
					
					// building cost of region
					NodeList CostList = firstRegionElement.getElementsByTagName("rBuildingCost");
					Element CostElement = (Element)CostList.item(0);
					NodeList rCostList = CostElement.getChildNodes();
					regions.get(s).rBuildingCost = Integer.parseInt(rCostList.item(0).getNodeValue());
					//System.out.println(regions.get(s).rBuildingCost);
					
					// number of minions in region
					NodeList MinionList = firstRegionElement.getElementsByTagName("NumberOfMinions");
					Element MinionElement = (Element)MinionList.item(0);
					NodeList rMinionList =  MinionElement.getChildNodes();
					regions.get(s).rMinionNum = Integer.parseInt(rMinionList.item(0).getNodeValue());
					//System.out.println(regions.get(s).rMinionNum);
					
					// number of trouble markers in region
					
					NodeList TMList = firstRegionElement.getElementsByTagName("NumberOfrTroubleMarkers");
					Element TMElement = (Element)TMList.item(0);
					NodeList rTMList =  TMElement.getChildNodes();
					regions.get(s).rTroubleMarker = Integer.parseInt(rTMList.item(0).getNodeValue());
					//System.out.println(regions.get(s).rTroubleMarker);
					
					// number of demons in region
					NodeList DList = firstRegionElement.getElementsByTagName("NumberOfrDemons");
					Element DElement = (Element)DList.item(0);
					NodeList DemonList =  DElement.getChildNodes();
					regions.get(s).rDemon = Integer.parseInt(DemonList.item(0).getNodeValue());
					//System.out.println(regions.get(s).rDemon);
					
					
					// number of trolls in region
					NodeList TList = firstRegionElement.getElementsByTagName("NumberOfrTrolls");
					Element TElement = (Element)TList.item(0);
					NodeList TrollList =  DElement.getChildNodes();
					regions.get(s).rTroll = Integer.parseInt(TrollList.item(0).getNodeValue());
					//System.out.println(regions.get(s).rTroll);
				} // end if

			}// end for
			
			for(int s=0; s<listOfPlayers.getLength() ; s++)
			{
				Node firstPlayerNode = listOfPlayers.item(s);
				if(firstPlayerNode.getNodeType() == Node.ELEMENT_NODE)
				{
					Element firstPlayerElement = (Element)firstPlayerNode; 
					
					// color of player's accessories
					NodeList ColorList = firstPlayerElement.getElementsByTagName("Color");
					Element ColorElement = (Element)ColorList.item(0);
					NodeList CList = ColorElement.getChildNodes();
					players.get(s).color = CList.item(0).getNodeValue();
					//System.out.println(players.get(s).color);
					
					// number of building with player currently
					NodeList BList = firstPlayerElement.getElementsByTagName("Building_Hold");
					Element BElement = (Element)BList.item(0);
					NodeList BuildingList = BElement.getChildNodes();
					players.get(s).buildingHold = Integer.parseInt(BuildingList.item(0).getNodeValue());
					//System.out.println(players.get(s).buildingHold);
					
					// amount of cash with player currently
					NodeList CashList = firstPlayerElement.getElementsByTagName("Cash_Hold");
					Element CashElement = (Element)CashList.item(0);
					NodeList pCashList = CashElement.getChildNodes();
					players.get(s).cashHold = Integer.parseInt(pCashList.item(0).getNodeValue());
					//System.out.println(players.get(s).cashHold);
					
					// number of minions with player currently
					NodeList MinionList = firstPlayerElement.getElementsByTagName("Minion_Hold");
					Element MinionElement = (Element)MinionList.item(0);
					NodeList MList = MinionElement.getChildNodes();
					players.get(s).minionHold = Integer.parseInt(MList.item(0).getNodeValue());
					//System.out.println(players.get(s).minionHold);
					
					
					// personality card with player currently
					NodeList PersonalityList = firstPlayerElement.getElementsByTagName("Personality");
					Element PersonalityElement = (Element)PersonalityList.item(0);
					NodeList PList = PersonalityElement.getChildNodes();
					players.get(s).personality = PList.item(0).getNodeValue();
					//System.out.println(players.get(s).personality);
					
					// player card with player currently
					NodeList PCardList = firstPlayerElement.getElementsByTagName("Player_Cards");
					Element PCardElement = (Element)PCardList.item(0);
					NodeList CardList = PCardElement.getChildNodes();
					/*players.get(s).H_Region*/ String value = CardList.item(0).getNodeValue();
					HashMap<String, List<Integer>> player_Cards = new HashMap<String, List<Integer>>();
					value = value.substring(1, value.length()-1);           //remove curly brackets
					String[] keyValuePair = value.split("=");              //split the string to create key-value pair
					String replace = keyValuePair[1].replace("[","");
					String replace1 = replace.replace("]","");
					List<String> tempList = new ArrayList<String>(Arrays.asList(replace1.split(",")));
				
					List<Integer> convertToInt = new ArrayList<Integer>();
					for(String a: tempList)
					{
						Integer temp = 0;
						temp = Integer.parseInt(a.trim());
						convertToInt.add(temp);
					}
				
					player_Cards.put(keyValuePair[0], convertToInt);
					players.get(s).pCards = player_Cards;
					//System.out.println(players.get(s).pCards.get("Green"));
					
				}// end if
			}// end for
			
			SavedGame Loaded =new SavedGame();
			for(int s = 0; s < listOfRegions.getLength() ; s++)
			{
				Loaded.Loaded_Region_Info.setValueAt(regions.get(s).rName, s, 0);
				Loaded.Loaded_Region_Info.setValueAt(regions.get(s).rMinionNum, s, 1);
				Loaded.Loaded_Region_Info.setValueAt(regions.get(s).rTroubleMarker, s, 3);
				Loaded.Loaded_Region_Info.setValueAt(regions.get(s).rDemon, s, 4);
				Loaded.Loaded_Region_Info.setValueAt(regions.get(s).rTroll, s, 5);
			}
			
			
			for(int s=0; s<listOfPlayers.getLength() ; s++)
			{
				Loaded.Loaded_Players_Info.setValueAt(players.get(s).color, s, 1);
				Loaded.Loaded_Players_Info.setValueAt(players.get(s).personality, s, 2);
				Loaded.Loaded_Players_Info.setValueAt(players.get(s).minionHold, s, 3);
				Loaded.Loaded_Players_Info.setValueAt(players.get(s).buildingHold, s, 4);
				Loaded.Loaded_Players_Info.setValueAt(players.get(s).cashHold, s, 5);
				Loaded.Loaded_Players_Info.setValueAt(players.get(s).pCards, s, 6);
			}
			Loaded.setVisible(true);
		  }// end try
		
					
		  catch (SAXParseException err) {
			  System.out.println ("** Parsing error" + ", line " + err.getLineNumber () + ", uri " + err.getSystemId ());
			  System.out.println(" " + err.getMessage ());

			  }catch (SAXException ee) {
			  Exception x = ee.getException ();
			  ((x == null) ? ee : x).printStackTrace ();

			  }catch (Throwable t) {
			  t.printStackTrace ();
			  }
	  }

//			            //Document readDoc = builder.build(new File("./src/Saved_Game.xml"));
//			            SavedGame Loaded =new SavedGame();
//			          
//			            Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getAttributeValue("player1"), 0, 0);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getChild("Player1_Color").getAttributeValue("color"), 0, 1);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getChild("Player1_personality").getAttributeValue("person"), 0, 2);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getChild("Player1_CardNo").getAttributeValue("Card_No"), 0, 6);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getChild("Player1_No_Minions").getAttributeValue("minions_No"), 0, 3);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getChild("Player1_No_Buildings").getAttributeValue("Buildings_No"), 0, 4);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player1").getChild("Player1_Money").getAttributeValue("Money"), 0, 5);
//						
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getAttributeValue("player2"), 1, 0);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getChild("Player2_Color").getAttributeValue("color"), 1, 1);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getChild("Player2_personality").getAttributeValue("person"), 1, 2);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getChild("Player2_CardNo").getAttributeValue("Card_No"), 1, 6);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getChild("Player2_No_Minions").getAttributeValue("minions_No"), 1, 3);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getChild("Player2_No_Buildings").getAttributeValue("Buildings_No"), 1, 4);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player2").getChild("Player2_Money").getAttributeValue("Money"), 1, 5);
//						
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getAttributeValue("player3"), 2, 0);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getChild("Player3_Color").getAttributeValue("color"), 2, 1);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getChild("Player3_personality").getAttributeValue("person"), 2, 2);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getChild("Player3_CardNo").getAttributeValue("Card_No"), 2, 6);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getChild("Player3_No_Minions").getAttributeValue("minions_No"), 2, 3);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getChild("Player3_No_Buildings").getAttributeValue("Buildings_No"), 2, 4);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player3").getChild("Player3_Money").getAttributeValue("Money"), 2, 5);
//						
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getAttributeValue("player4"), 3, 0);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getChild("Player4_Color").getAttributeValue("color"), 3, 1);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getChild("Player4_personality").getAttributeValue("person"), 3, 2);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getChild("Player4_CardNo").getAttributeValue("Card_No"), 3, 6);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getChild("Player4_No_Minions").getAttributeValue("minions_No"), 3, 3);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getChild("Player4_No_Buildings").getAttributeValue("Buildings_No"), 3, 4);
//						Loaded.Loaded_Players_Info.setValueAt(readDoc.getRootElement().getChild("player4").getChild("Player4_Money").getAttributeValue("Money"), 3, 5);
//						
//						
//						
//						Loaded.setVisible(true);
//						
//		        
//					
//			}
//		
//		
//		
//
//			catch (JDOMException e1) {
//	            e1.printStackTrace();
//	        }
//	         
//	        catch (IOException e1) {
//	            // TODO Auto-generated catch block
//	            e1.printStackTrace();
//	        }
		
//		  }
	//	  else JOptionPane.showMessageDialog(null, "No Saved File Exist To Load !");
		  
		
	}

	private String getCharacterDataFromElement(Element regionNumberElement) {
		// TODO Auto-generated method stub
		return null;
	}

	private void Start_GameActionPerformed(ActionEvent e) {
		// TODO add your code here
		
		if (e.getSource()==Start_Game ){
			
			NewGame Game = new NewGame();		// create Object from the Player Class the will display the form
			Game.setVisible(true); 	// make it visible
			//Form.setVisible(true);
			//JOptionPane.showMessageDialog(null, "You've got it !");
			
		}
	}

	private void initComponents() {
		//  Component initialization - DO NOT MODIFY  
	
		panel1 = new JPanel();
		Load_Game = new JButton();
		Start_Game = new JButton();

		//======== this ========
		setTitle("Game Build1");
		Container contentPane = getContentPane();
		contentPane.setLayout(null);

		//======== panel1 ========
		{

			


			//---- Load_Game ----
			Load_Game.setText("Load Saved Game");
			Load_Game.setFont(new Font("Tahoma", Font.PLAIN, 24));
			Load_Game.setForeground(Color.blue);
			Load_Game.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Load_GameActionPerformed(e);
					//Load_GameActionPerformed(e);
				}
			});

			//---- Start_Game ----
			Start_Game.setText("Start New Game");
			Start_Game.setForeground(Color.blue);
			Start_Game.setFont(new Font("Tahoma", Font.PLAIN, 24));
			Start_Game.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					Start_GameActionPerformed(e);
				}
			});

			GroupLayout panel1Layout = new GroupLayout(panel1);
			panel1.setLayout(panel1Layout);
			panel1Layout.setHorizontalGroup(
				panel1Layout.createParallelGroup()
					.addGroup(panel1Layout.createSequentialGroup()
						.addContainerGap(47, Short.MAX_VALUE)
						.addGroup(panel1Layout.createParallelGroup()
							.addComponent(Load_Game, GroupLayout.PREFERRED_SIZE, 244, GroupLayout.PREFERRED_SIZE)
							.addComponent(Start_Game, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addContainerGap(54, Short.MAX_VALUE))
			);
			panel1Layout.setVerticalGroup(
				panel1Layout.createParallelGroup()
					.addGroup(panel1Layout.createSequentialGroup()
						.addContainerGap()
						.addComponent(Load_Game, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
						.addGap(35, 35, 35)
						.addComponent(Start_Game, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(23, Short.MAX_VALUE))
			);
		}
		contentPane.add(panel1);
		panel1.setBounds(0, 0, 345, 170);

		{ // compute preferred size
			Dimension preferredSize = new Dimension();
			for(int i = 0; i < contentPane.getComponentCount(); i++) {
				Rectangle bounds = contentPane.getComponent(i).getBounds();
				preferredSize.width = Math.max(bounds.x + bounds.width, preferredSize.width);
				preferredSize.height = Math.max(bounds.y + bounds.height, preferredSize.height);
			}
			Insets insets = contentPane.getInsets();
			preferredSize.width += insets.right;
			preferredSize.height += insets.bottom;
			contentPane.setMinimumSize(preferredSize);
			contentPane.setPreferredSize(preferredSize);
		}
		pack();
		setLocationRelativeTo(getOwner());
		//  - End of component initialization 
	}

	//  - Variables declaration - DO NOT MODIFY 
	
	private JPanel panel1;
	private JButton Load_Game;
	private JButton Start_Game;
	// - End of variables declaration  
	public void run()
	{
		GameEngine Form = new GameEngine();		// create Object from the Player Class the will display the form
		Form.setVisible(true); 	// make it visible
	}
	
	
	public static void main(String[] args) 
	{
		objDSisters = new Region("Dolly Sisters", 1, 6);
		regions.add(objDSisters);
		objUEstate = new Region("Unreal Estate", 2, 18);
		regions.add(objUEstate);
		objDLanding = new Region("Dragon's Landing", 3, 12);
		regions.add(objDLanding);
		objSGods = new Region("Small Gods", 4, 18);
		regions.add(objSGods);
		objTScours = new Region("The Scours", 5, 6);
		regions.add(objTScours);
		objTHippo = new Region("The Hippo", 6, 12);
		regions.add(objTHippo);
		objTShades = new Region("The Shades", 7, 6);
		regions.add(objTShades);
		objDimwell = new Region("Dimwell", 8, 6);
		regions.add(objDimwell);
		objLongwall = new Region("Longwall", 9, 12);
		regions.add(objLongwall);
		objIGods = new Region("Isle of Gods", 10, 12);
		regions.add(objIGods);
		objSSleepers = new Region("Seven Sleepers", 11, 18);
		regions.add(objSSleepers);
		objNHill = new Region("Nap Hill", 12, 12);
		regions.add(objNHill);
		PlayerCards.createPlayerCardsDeck();
		String personality_temp;
		personality_temp = PersonalityCards.shufflePersonalityCards();
		pRed = new Player("red", personality_temp);
		players.add(pRed);
		
		personality_temp = PersonalityCards.shufflePersonalityCards();
		pYellow = new Player("yellow", personality_temp);
		players.add(pYellow);
		
		personality_temp = PersonalityCards.shufflePersonalityCards();
		pGreen = new Player("green", personality_temp);
		players.add(pGreen);
		
		personality_temp = PersonalityCards.shufflePersonalityCards();
		pBlue = new Player("blue", personality_temp);
		players.add(pBlue);
		
		(new Thread(new GameEngine())).start();
		
		//System.out.println("Wrote to file");
		
	}
	
	public static void createXML() {
		
		DocumentBuilderFactory icFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder icBuilder;
		try {
			icBuilder = icFactory.newDocumentBuilder();
			Document doc = icBuilder.newDocument();
			Element mainRootElement = doc.createElementNS("CreateXMLDOM",
					"XML");
			doc.appendChild(mainRootElement);
			//Element regionsTag = doc.createElement("Regions");
			//Element playersTag = doc.createElement("Players");
			// append child elements to root element
			//mainRootElement.appendChild(regionsTag);
			//mainRootElement.appendChild(playersTag);
			for(Region a:regions)
			{
				mainRootElement.appendChild(getRegion(doc,a.rName,a.rNumber, a.rBuildingCost, a.rMinionNum, a.rTroubleMarker, a.rDemon,a.rTroll));
			}
			int count = 1;
			for(Player a:players)
			{
				mainRootElement.appendChild(getPlayer(doc,a.color, a.buildingHold, a.cashHold, a.minionHold, a.personality, a.pCards, count));
				count++;
			}
			// output DOM XML to console
			Transformer transformer = TransformerFactory.newInstance()
					.newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc);
			StreamResult file = new StreamResult(new File(
					"./src/Saved_Game.xml"));
			transformer.transform(source, file);

			//System.out.println("\nXML DOM Created Successfully..");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Node getRegion(Document doc, String name, int rNumber,
			int rBuildingCost, int rMinionNum, int rTroubleMarker, int rDemon,
			int rTroll) {
		
		Element region = doc.createElement("Region");
		//region.setAttribute("Name", name);
		Element Region_name = doc.createElement("Name");
		Region_name.appendChild(doc.createTextNode(name));
		region.appendChild(Region_name);
		region.appendChild(getRegionElements(doc, region, "RegionNumber",
				rNumber));
		region.appendChild(getRegionElements(doc, region, "rBuildingCost",
				rBuildingCost));
		region.appendChild(getRegionElements(doc, region, "NumberOfMinions",
				rMinionNum));
		region.appendChild(getRegionElements(doc, region,
				"NumberOfrTroubleMarkers", rTroubleMarker));
		region.appendChild(getRegionElements(doc, region, "NumberOfrDemons",
				rDemon));
		region.appendChild(getRegionElements(doc, region, "NumberOfrTrolls",
				rTroll));
		return region;
	}

	// utility method to create text node
	public static Node getRegionElements(Document doc, Element element,
			String name, int value) {
		Element node = doc.createElement(name);
		// node.appendChild(doc.createTextNode(value));
		node.appendChild(doc.createTextNode(Integer.toString(value)));
		return node;
	}
	
	public static Node getPlayer(Document doc, String color, int buildingHold, int cashHold, int minionHold, String personality, HashMap<String, List<Integer>> pCards, int playerNumber)
	{
		//Integer count = 1;
		Element player = doc.createElement("Player");
		player.setAttribute("Number", Integer.toString(playerNumber));
		//count++;
		Element Player_color = doc.createElement("Color");
		Player_color.appendChild(doc.createTextNode(color));
		player.appendChild(Player_color);
		player.appendChild(getPlayerElements(doc, player, "Building_Hold",
				buildingHold));
		player.appendChild(getPlayerElements(doc, player, "Cash_Hold",
				cashHold));
		player.appendChild(getPlayerElements(doc, player, "Minion_Hold",
				minionHold));
		Element Personality = doc.createElement("Personality");
		Personality.appendChild(doc.createTextNode(personality));
		player.appendChild(Personality);
		
		Element Player_Cards = doc.createElement("Player_Cards");
		Player_Cards.appendChild(doc.createTextNode(pCards.toString()));
		player.appendChild(Player_Cards);
		return player;
		
	}
	public static Node getPlayerElements(Document doc, Element element,
			String name, int value) {
		Element node = doc.createElement(name);
		// node.appendChild(doc.createTextNode(value));
		node.appendChild(doc.createTextNode(Integer.toString(value)));
		return node;
	}
}
